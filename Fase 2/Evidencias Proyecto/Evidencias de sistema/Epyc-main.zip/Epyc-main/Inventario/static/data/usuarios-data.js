// Copia embebida de usuarios.json para vistas sin servidor (ver admin-datos.js).
var USUARIOS_DATA = [
  {
    "id": 1,
    "nombre": "Helen Cortés",
    "correo": "helen@entreplatosycopas.cl",
    "rol": "Administrador",
    "estado": "Activo",
    "ultimoAcceso": "2026-08-17 09:12"
  },
  {
    "id": 2,
    "nombre": "Ignacio Vera",
    "correo": "ignacio@entreplatosycopas.cl",
    "rol": "Administrativo / Ventas",
    "estado": "Activo",
    "ultimoAcceso": "2026-08-16 18:40"
  },
  {
    "id": 3,
    "nombre": "Bodega Central",
    "correo": "bodega@entreplatosycopas.cl",
    "rol": "Bodega / Operaciones",
    "estado": "Activo",
    "ultimoAcceso": "2026-08-17 08:05"
  },
  {
    "id": 4,
    "nombre": "Camila Reyes",
    "correo": "camila@entreplatosycopas.cl",
    "rol": "Administrativo / Ventas",
    "estado": "Inactivo",
    "ultimoAcceso": "2026-07-02 11:20"
  }
];
